const getProfile = (req, res) => {
  res.send("Router is working");
};

module.exports = getProfile;
